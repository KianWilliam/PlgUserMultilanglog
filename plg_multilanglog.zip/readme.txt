User - Multilanglog version 1.0.0  is a free software which is developed by
Kian William Nowrouzian, it is written clearly, too clear 
to add any comments excepting those needed for GPL,
The license is GNU/GPLv3
It is written for joomla 3.x, Those who have a multi language website, on login from each language
to make the site redirects to the correct menuitem or file of the same language this very simple plugin is of use.
you may download the plugin at:
http://www.extensions.lord121.ir/myplugins/multilanglog.html
and enable it after upload to your joomla site.
I have to add I used the advice and insight of Sergey Onichshenkov to develop this module,
also in case of any question email me at:
mezmer121@gmail.com
or go to http://www.extensions.lord121.ir/support.html and send me a message.
long live science.
